package com.revature.race;

public class IntWrapper {

    private int value = 0;

    public int getValue() {
        return value;
    }

    public void incrementValue() {
        value = value + 1;
    }

}
